class inputSaree:
    purchaseId = "" 
    price = 0
    imageOverview = ''
    imageBorder = ''
    imageFullview = ''
    imagepallu = '' 